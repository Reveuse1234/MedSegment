from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import streamlit as st
import torch

from model_utils import (
    array_to_png_bytes,
    binary_whole_tumour,
    load_model,
    load_nifti_bytes,
    make_overlay,
    nifti_mask_bytes,
    predict_probability_volume,
    rotate_for_display,
    segmentation_metrics,
    valid_nifti_name,
    window_for_display,
)


APP_ROOT = Path(__file__).resolve().parent
MODEL_PATH = APP_ROOT / "model" / "final_model_dice_bce.pt"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


st.set_page_config(
    page_title="Brain Tumour Segmentation",
    page_icon="🧠",
    layout="wide",
)


@st.cache_resource(show_spinner=False)
def get_model():
    return load_model(MODEL_PATH, DEVICE)


def clear_previous_result() -> None:
    for key in (
        "inference_result",
        "input_hash",
        "slice_index",
    ):
        st.session_state.pop(key, None)


def uploaded_file_hash(file_bytes: bytes) -> str:
    return hashlib.sha256(file_bytes).hexdigest()


def display_model_information(checkpoint: dict) -> None:
    configuration = checkpoint.get("configuration", {})
    st.sidebar.markdown("### Model")
    st.sidebar.write("**Architecture:** 2D U-Net")
    st.sidebar.write("**Input modality:** FLAIR MRI")
    st.sidebar.write("**Selected loss:** Dice + BCE")
    st.sidebar.write(
        f"**Validation Dice:** {checkpoint.get('best_val_dice', float('nan')):.4f}"
    )
    st.sidebar.write(f"**Input size:** {configuration.get('image_size', 128)} × {configuration.get('image_size', 128)}")
    st.sidebar.write(f"**Device:** {DEVICE}")


st.title("Brain Tumour Segmentation Using 2D U-Net")
st.write(
    "Upload a BraTS-format or similarly preprocessed **FLAIR brain MRI** "
    "in NIfTI format. The model processes the complete 3D volume slice by "
    "slice and creates a predicted whole-tumour mask."
)

st.warning(
    "Academic research prototype only. This application is not intended "
    "for clinical diagnosis or medical decision-making."
)

try:
    model, checkpoint = get_model()
except Exception as error:
    st.error(f"The trained model could not be loaded: {error}")
    st.stop()

configuration = checkpoint.get("configuration", {})
image_size = int(configuration.get("image_size", 128))
display_model_information(checkpoint)

with st.sidebar:
    st.markdown("### Prediction settings")
    threshold = st.slider(
        "Tumour probability threshold",
        min_value=0.10,
        max_value=0.90,
        value=0.50,
        step=0.05,
        help="Pixels with probability at or above this value are marked as tumour.",
    )
    batch_size = st.select_slider(
        "Inference batch size",
        options=[1, 2, 4, 8, 16, 32],
        value=16,
        help="Reduce this if the computer runs out of memory.",
    )
    st.markdown("### Supported input")
    st.write("• Brain FLAIR MRI")
    st.write("• 3D `.nii` or `.nii.gz`")
    st.write("• BraTS-style preprocessing")

flair_file = st.file_uploader(
    "Upload a FLAIR MRI volume",
    type=["nii", "gz"],
    accept_multiple_files=False,
    help="Use a 3D BraTS-format FLAIR NIfTI scan.",
)

ground_truth_file = st.file_uploader(
    "Optional: upload the matching ground-truth segmentation",
    type=["nii", "gz"],
    accept_multiple_files=False,
    help="This is optional and is used only to calculate Dice and IoU.",
)

if flair_file is None:
    st.info("Upload a FLAIR `.nii` or `.nii.gz` file to begin.")
    st.stop()

if not valid_nifti_name(flair_file.name):
    st.error("The FLAIR file must end in `.nii` or `.nii.gz`.")
    st.stop()

flair_bytes = flair_file.getvalue()
current_hash = uploaded_file_hash(flair_bytes)

if st.session_state.get("input_hash") not in (None, current_hash):
    clear_previous_result()

run_prediction = st.button(
    "Run tumour segmentation",
    type="primary",
    use_container_width=True,
)

if run_prediction:
    progress = st.progress(0, text="Loading the MRI volume...")
    try:
        volume, affine, header = load_nifti_bytes(flair_bytes, flair_file.name)
        progress.progress(20, text="Loading the trained Dice+BCE model...")

        probability_volume, brain_slices = predict_probability_volume(
            model=model,
            volume=volume,
            device=DEVICE,
            image_size=image_size,
            batch_size=int(batch_size),
        )
        progress.progress(85, text="Preparing the result...")

        ground_truth = None
        ground_truth_error = None
        if ground_truth_file is not None:
            if not valid_nifti_name(ground_truth_file.name):
                ground_truth_error = "Ground-truth file must end in .nii or .nii.gz."
            else:
                ground_truth_volume, _, _ = load_nifti_bytes(
                    ground_truth_file.getvalue(),
                    ground_truth_file.name,
                )
                if ground_truth_volume.shape != volume.shape:
                    ground_truth_error = (
                        "Ground-truth shape does not match the FLAIR scan: "
                        f"{ground_truth_volume.shape} vs {volume.shape}."
                    )
                else:
                    ground_truth = binary_whole_tumour(ground_truth_volume)

        provisional_mask = probability_volume >= threshold
        predicted_area = provisional_mask.sum(axis=(0, 1))
        default_slice = int(np.argmax(predicted_area))
        if predicted_area[default_slice] == 0:
            default_slice = int(brain_slices[len(brain_slices) // 2])

        st.session_state["inference_result"] = {
            "filename": flair_file.name,
            "volume": volume,
            "probability": probability_volume,
            "affine": affine,
            "header": header,
            "brain_slices": brain_slices,
            "ground_truth": ground_truth,
            "ground_truth_error": ground_truth_error,
        }
        st.session_state["input_hash"] = current_hash
        st.session_state["slice_index"] = default_slice
        progress.progress(100, text="Segmentation complete.")
    except Exception as error:
        progress.empty()
        st.error(f"Segmentation failed: {error}")
        st.stop()

result = st.session_state.get("inference_result")
if result is None:
    st.stop()

volume = result["volume"]
probability_volume = result["probability"]
predicted_mask = probability_volume >= threshold
ground_truth = result["ground_truth"]

if result.get("ground_truth_error"):
    st.warning(result["ground_truth_error"])

height, width, depth = volume.shape
predicted_voxels = int(predicted_mask.sum())
voxel_dimensions = result["header"].get_zooms()[:3]
voxel_volume_mm3 = float(np.prod(voxel_dimensions))
predicted_volume_ml = predicted_voxels * voxel_volume_mm3 / 1000.0
slices_with_prediction = int(np.count_nonzero(predicted_mask.sum(axis=(0, 1))))

st.success("Segmentation completed successfully.")

metric_columns = st.columns(4)
metric_columns[0].metric("MRI shape", f"{height} × {width} × {depth}")
metric_columns[1].metric("Predicted tumour voxels", f"{predicted_voxels:,}")
metric_columns[2].metric("Estimated mask volume", f"{predicted_volume_ml:.2f} mL")
metric_columns[3].metric("Slices containing prediction", slices_with_prediction)

if ground_truth is not None:
    whole_volume_metrics = segmentation_metrics(predicted_mask, ground_truth)
    metric_columns = st.columns(2)
    metric_columns[0].metric(
        "Whole-volume Dice",
        f"{whole_volume_metrics['dice']:.4f}",
    )
    metric_columns[1].metric(
        "Whole-volume IoU",
        f"{whole_volume_metrics['iou']:.4f}",
    )

if "slice_index" not in st.session_state:
    st.session_state["slice_index"] = int(
        np.argmax(predicted_mask.sum(axis=(0, 1)))
    )

slice_index = st.slider(
    "Axial slice",
    min_value=0,
    max_value=depth - 1,
    key="slice_index",
)

image_slice = volume[:, :, slice_index]
probability_slice = probability_volume[:, :, slice_index]
mask_slice = predicted_mask[:, :, slice_index]
overlay = make_overlay(image_slice, mask_slice)

if ground_truth is None:
    columns = st.columns(3)
else:
    columns = st.columns(4)

with columns[0]:
    st.subheader("FLAIR MRI")
    st.image(
        rotate_for_display(window_for_display(image_slice)),
        clamp=True,
        use_container_width=True,
    )

column_offset = 1
if ground_truth is not None:
    with columns[1]:
        st.subheader("Ground truth")
        st.image(
            rotate_for_display(ground_truth[:, :, slice_index]),
            clamp=True,
            use_container_width=True,
        )
    column_offset = 2

with columns[column_offset]:
    st.subheader("Predicted mask")
    st.image(
        rotate_for_display(mask_slice.astype(np.float32)),
        clamp=True,
        use_container_width=True,
    )

with columns[column_offset + 1]:
    st.subheader("Prediction overlay")
    st.image(overlay, clamp=True, use_container_width=True)

slice_metric_columns = st.columns(3)
slice_metric_columns[0].metric("Selected slice", slice_index)
slice_metric_columns[1].metric(
    "Maximum probability on slice",
    f"{float(probability_slice.max()):.3f}",
)
slice_metric_columns[2].metric(
    "Predicted pixels on slice",
    f"{int(mask_slice.sum()):,}",
)

if ground_truth is not None:
    current_slice_metrics = segmentation_metrics(
        mask_slice,
        ground_truth[:, :, slice_index],
    )
    st.write(
        f"**Selected-slice Dice:** {current_slice_metrics['dice']:.4f}  |  "
        f"**Selected-slice IoU:** {current_slice_metrics['iou']:.4f}"
    )

st.markdown("### Download results")
mask_bytes = nifti_mask_bytes(
    predicted_mask.astype(np.uint8),
    result["affine"],
    result["header"],
)

base_name = result["filename"]
if base_name.lower().endswith(".nii.gz"):
    base_name = base_name[:-7]
elif base_name.lower().endswith(".nii"):
    base_name = base_name[:-4]

summary_lines = [
    "Brain Tumour Segmentation Using 2D U-Net",
    f"Input file: {result['filename']}",
    f"Input shape: {height} x {width} x {depth}",
    f"Threshold: {threshold:.2f}",
    f"Predicted tumour voxels: {predicted_voxels}",
    f"Estimated predicted mask volume: {predicted_volume_ml:.4f} mL",
    f"Slices containing prediction: {slices_with_prediction}",
]
if ground_truth is not None:
    summary_lines.extend(
        [
            f"Whole-volume Dice: {whole_volume_metrics['dice']:.6f}",
            f"Whole-volume IoU: {whole_volume_metrics['iou']:.6f}",
        ]
    )
summary_lines.append(
    "Disclaimer: Academic research prototype; not for clinical diagnosis."
)
summary_text = "\n".join(summary_lines)

download_columns = st.columns(3)
with download_columns[0]:
    st.download_button(
        "Download predicted mask (.nii.gz)",
        data=mask_bytes,
        file_name=f"{base_name}_predicted_whole_tumour.nii.gz",
        mime="application/gzip",
        use_container_width=True,
    )
with download_columns[1]:
    st.download_button(
        "Download current overlay (.png)",
        data=array_to_png_bytes(overlay),
        file_name=f"{base_name}_slice_{slice_index}_overlay.png",
        mime="image/png",
        use_container_width=True,
    )
with download_columns[2]:
    st.download_button(
        "Download result summary (.txt)",
        data=summary_text,
        file_name=f"{base_name}_segmentation_summary.txt",
        mime="text/plain",
        use_container_width=True,
    )

with st.expander("Important limitations"):
    st.write(
        "This model was trained only on BraTS 2020 FLAIR MRI scans. It "
        "segments a binary whole-tumour region and does not distinguish "
        "tumour subregions. It has not been clinically validated on raw "
        "hospital DICOM scans or data from different acquisition pipelines."
    )
