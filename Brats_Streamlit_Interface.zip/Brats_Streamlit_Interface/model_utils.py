from __future__ import annotations

import io
import os
import tempfile
from pathlib import Path
from typing import Any

import nibabel as nib
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image


class DoubleConv(nn.Module):
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class Down(nn.Module):
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        self.block = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, out_channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class Up(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_channels, out_channels, 2, stride=2)
        self.conv = DoubleConv(out_channels + skip_channels, out_channels)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = self.up(x)
        diff_y = skip.size(2) - x.size(2)
        diff_x = skip.size(3) - x.size(3)
        x = F.pad(
            x,
            [
                diff_x // 2,
                diff_x - diff_x // 2,
                diff_y // 2,
                diff_y - diff_y // 2,
            ],
        )
        return self.conv(torch.cat([skip, x], dim=1))


class UNet2D(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 1,
        base: int = 16,
    ):
        super().__init__()
        self.input_block = DoubleConv(in_channels, base)
        self.down1 = Down(base, base * 2)
        self.down2 = Down(base * 2, base * 4)
        self.down3 = Down(base * 4, base * 8)
        self.down4 = Down(base * 8, base * 16)
        self.dropout = nn.Dropout2d(0.30)
        self.up1 = Up(base * 16, base * 8, base * 8)
        self.up2 = Up(base * 8, base * 4, base * 4)
        self.up3 = Up(base * 4, base * 2, base * 2)
        self.up4 = Up(base * 2, base, base)
        self.output = nn.Conv2d(base, out_channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x1 = self.input_block(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.dropout(self.down4(x4))
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        return self.output(x)


def safe_torch_load(path: str | Path, device: torch.device) -> dict[str, Any]:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=device)


def load_model(
    checkpoint_path: str | Path,
    device: torch.device,
) -> tuple[UNet2D, dict[str, Any]]:
    checkpoint_path = Path(checkpoint_path)
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Model checkpoint not found: {checkpoint_path}")

    checkpoint = safe_torch_load(checkpoint_path, device)
    configuration = checkpoint.get("configuration", {})
    base_filters = int(configuration.get("base_filters", 16))

    model = UNet2D(base=base_filters).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, checkpoint


def valid_nifti_name(filename: str) -> bool:
    lower = filename.lower()
    return lower.endswith(".nii") or lower.endswith(".nii.gz")


def load_nifti_bytes(
    file_bytes: bytes,
    filename: str,
) -> tuple[np.ndarray, np.ndarray, nib.Nifti1Header]:
    if not valid_nifti_name(filename):
        raise ValueError("Only .nii and .nii.gz NIfTI files are supported.")

    suffix = ".nii.gz" if filename.lower().endswith(".nii.gz") else ".nii"
    temporary_path = None

    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as temporary:
            temporary.write(file_bytes)
            temporary_path = temporary.name

        image = nib.load(temporary_path)
        volume = np.asarray(image.dataobj, dtype=np.float32)
        affine = np.asarray(image.affine, dtype=np.float64).copy()
        header = image.header.copy()
    finally:
        if temporary_path and os.path.exists(temporary_path):
            os.unlink(temporary_path)

    if volume.ndim == 4 and volume.shape[-1] == 1:
        volume = volume[..., 0]

    if volume.ndim != 3:
        raise ValueError(
            f"Expected a 3D MRI volume, but received shape {volume.shape}."
        )

    if not np.isfinite(volume).all():
        volume = np.nan_to_num(volume, nan=0.0, posinf=0.0, neginf=0.0)

    return volume, affine, header


def normalize_flair(volume: np.ndarray) -> np.ndarray:
    """Apply the same brain-region z-score normalization used during training."""
    volume = volume.astype(np.float32, copy=False)
    brain = volume > 0
    values = volume[brain]

    if values.size == 0:
        raise ValueError(
            "The uploaded scan contains no positive-valued brain voxels. "
            "Use a BraTS-format or similarly preprocessed FLAIR MRI."
        )

    mean = float(values.mean())
    std = float(values.std())
    if std < 1e-8:
        std = 1.0

    normalized = np.zeros_like(volume, dtype=np.float32)
    normalized[brain] = (volume[brain] - mean) / std
    return np.clip(normalized, -5.0, 5.0)


@torch.inference_mode()
def predict_probability_volume(
    model: nn.Module,
    volume: np.ndarray,
    device: torch.device,
    image_size: int = 128,
    batch_size: int = 16,
    minimum_brain_pixels: int = 200,
) -> tuple[np.ndarray, list[int]]:
    if volume.ndim != 3:
        raise ValueError("Prediction requires a 3D volume.")

    height, width, depth = volume.shape
    normalized = normalize_flair(volume)

    brain_slices = [
        z
        for z in range(depth)
        if int(np.count_nonzero(volume[:, :, z] > 0)) >= minimum_brain_pixels
    ]

    if not brain_slices:
        raise ValueError(
            "No usable brain slices were detected. The scan may not be "
            "BraTS-formatted or skull-stripped."
        )

    probability_volume = np.zeros((height, width, depth), dtype=np.float32)

    for start in range(0, len(brain_slices), batch_size):
        slice_indices = brain_slices[start : start + batch_size]
        image_stack = np.stack(
            [normalized[:, :, z] for z in slice_indices],
            axis=0,
        )

        tensor = torch.from_numpy(image_stack).unsqueeze(1).float().to(device)
        resized = F.interpolate(
            tensor,
            size=(image_size, image_size),
            mode="bilinear",
            align_corners=False,
        )

        probabilities = torch.sigmoid(model(resized))
        probabilities = F.interpolate(
            probabilities,
            size=(height, width),
            mode="bilinear",
            align_corners=False,
        )
        probabilities = probabilities[:, 0].cpu().numpy().astype(np.float32)

        for local_index, z in enumerate(slice_indices):
            probability_slice = probabilities[local_index]
            probability_slice[volume[:, :, z] <= 0] = 0.0
            probability_volume[:, :, z] = probability_slice

    return probability_volume, brain_slices


def binary_whole_tumour(segmentation: np.ndarray) -> np.ndarray:
    segmentation = np.asarray(segmentation)
    # Supports BraTS labels 1, 2 and 4 as well as a binary 0/1 mask.
    return np.isin(segmentation, [1, 2, 4]).astype(np.uint8)


def segmentation_metrics(
    prediction: np.ndarray,
    target: np.ndarray,
    epsilon: float = 1e-8,
) -> dict[str, float]:
    prediction = np.asarray(prediction).astype(bool)
    target = np.asarray(target).astype(bool)

    if prediction.shape != target.shape:
        raise ValueError(
            f"Prediction and target shapes differ: {prediction.shape} vs {target.shape}"
        )

    intersection = np.logical_and(prediction, target).sum(dtype=np.float64)
    union = np.logical_or(prediction, target).sum(dtype=np.float64)
    prediction_sum = prediction.sum(dtype=np.float64)
    target_sum = target.sum(dtype=np.float64)

    if prediction_sum == 0 and target_sum == 0:
        dice = 1.0
        iou = 1.0
    else:
        dice = (2.0 * intersection) / (prediction_sum + target_sum + epsilon)
        iou = intersection / (union + epsilon)

    return {
        "dice": float(dice),
        "iou": float(iou),
        "prediction_pixels": int(prediction_sum),
        "target_pixels": int(target_sum),
    }


def window_for_display(image_slice: np.ndarray) -> np.ndarray:
    image_slice = np.asarray(image_slice, dtype=np.float32)
    finite = image_slice[np.isfinite(image_slice)]
    foreground = finite[finite > 0]

    values = foreground if foreground.size else finite
    if values.size == 0:
        return np.zeros_like(image_slice, dtype=np.float32)

    low, high = np.percentile(values, [1.0, 99.0])
    if high <= low:
        low = float(values.min())
        high = float(values.max())
    if high <= low:
        return np.zeros_like(image_slice, dtype=np.float32)

    displayed = np.clip((image_slice - low) / (high - low), 0.0, 1.0)
    return displayed.astype(np.float32)


def rotate_for_display(array: np.ndarray) -> np.ndarray:
    return np.rot90(np.asarray(array))


def make_overlay(
    image_slice: np.ndarray,
    mask_slice: np.ndarray,
    alpha: float = 0.45,
) -> np.ndarray:
    grayscale = rotate_for_display(window_for_display(image_slice))
    mask = rotate_for_display(mask_slice.astype(bool))
    rgb = np.repeat(grayscale[..., None], 3, axis=2)

    overlay_colour = np.zeros_like(rgb)
    overlay_colour[..., 0] = 1.0
    rgb[mask] = (
        (1.0 - alpha) * rgb[mask]
        + alpha * overlay_colour[mask]
    )
    return np.clip(rgb, 0.0, 1.0)


def array_to_png_bytes(array: np.ndarray) -> bytes:
    array = np.asarray(array)
    if array.dtype == bool:
        array = array.astype(np.uint8) * 255
    elif np.issubdtype(array.dtype, np.floating):
        array = np.clip(array, 0.0, 1.0)
        array = (array * 255.0).round().astype(np.uint8)
    else:
        array = np.clip(array, 0, 255).astype(np.uint8)

    image = Image.fromarray(array)
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def nifti_mask_bytes(
    mask: np.ndarray,
    affine: np.ndarray,
    header: nib.Nifti1Header,
) -> bytes:
    output_header = header.copy()
    output_header.set_data_dtype(np.uint8)
    output_image = nib.Nifti1Image(
        mask.astype(np.uint8),
        affine,
        header=output_header,
    )

    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".nii.gz", delete=False) as temporary:
            temporary_path = temporary.name
        nib.save(output_image, temporary_path)
        return Path(temporary_path).read_bytes()
    finally:
        if temporary_path and os.path.exists(temporary_path):
            os.unlink(temporary_path)
