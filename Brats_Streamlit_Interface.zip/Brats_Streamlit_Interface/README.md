# Brain Tumour Segmentation — Streamlit Interface

This project provides a Streamlit interface for the trained **Dice+BCE 2D U-Net** developed for whole-tumour segmentation from BraTS 2020 FLAIR MRI scans.

## What the interface does

- Accepts a 3D FLAIR MRI volume in `.nii` or `.nii.gz` format.
- Applies the same intensity normalization used during model training.
- Processes the complete volume slice by slice.
- Displays the FLAIR slice, predicted mask and tumour overlay.
- Allows axial-slice browsing and threshold adjustment.
- Downloads the complete predicted mask as a `.nii.gz` volume.
- Optionally accepts a matching ground-truth segmentation and calculates Dice and IoU.

## Input requirements

Use a BraTS-format or similarly preprocessed:

- brain MRI,
- FLAIR modality,
- three-dimensional NIfTI volume,
- skull-stripped and spatially standardized scan.

Raw hospital DICOM scans are not supported by this version.

## Run locally

### 1. Extract the ZIP

Keep the project folders and files in their existing structure. The model should remain at:

```text
model/final_model_dice_bce.pt
```

### 2. Open the folder in VS Code

Open a terminal in the project directory.

### 3. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Start the application

```bash
streamlit run app.py
```

The terminal will provide a local address, normally:

```text
http://localhost:8501
```

## Using the application

1. Upload a BraTS FLAIR file such as `BraTS20_Training_296_flair.nii`.
2. Optionally upload the matching segmentation file.
3. Click **Run tumour segmentation**.
4. Browse the axial slices.
5. Download the predicted whole-tumour mask.

## Model information

- Architecture: 2D U-Net
- Modality: FLAIR MRI
- Output: binary whole-tumour mask
- Training loss: combined Dice and binary cross-entropy
- Input size per slice: 128 × 128
- Best validation Dice: approximately 0.8811

## Disclaimer

This application is an academic research prototype. It is not intended for clinical diagnosis, treatment planning or medical decision-making.
